win_pts = [0, 0, 2, 5, 20]
debug_mode = False