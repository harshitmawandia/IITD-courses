# To scan and Parse a file named **filename**
1. run *make*
2. run *use "execute.sml";*
3. run *execute "filename";*

### If you PC does not have make installed :
1. run *ml-lex lexer.lex*
2. run *ml-yacc parser.yacc*
3. run *sml*
4. run *use "execute.sml";*
3. run *execute "filename";*

## I have made certain decision to make the grammar unambiguous:
This includes using "(" and ")" at every expression which contains more than 1 Factor(A non Terminal dataType).
This makes the grammar unambigous. There are no reduce-reduce or shift-reduce conflicts in this grammar.

## I have used certain resources and taken help from certain pages on the web
1. http://rogerprice.org/ug/ug.pdf (A short documentation on the use of ML-LEX and ML-YACC)
2. http://cs.wellesley.edu/~cs235/fall08/lectures/35_YACC_revised.pdf 
   A lecture slide from Wellesley College on Languages and Automata

# The files I have used in this project are :
1. *lexer.lex* : This file is used to read all the tokens from the file as keywords, operators, seperators, variables and constants
2. *parser.yacc* : This file is used to parse the stream of tokens and create an AST datastructure.
3. *datatypes.sml* : It contains the AST structure and is also used to create the symbol table and also for type checking. It also maintains the Memory array.
4. *glue.sml* : This file glues all the lexing and parsing functions. It takes input a file name in the function parseFile() and then first reads the file as a string to convert them into tokens and then use the tokens to create an AST using the .yacc.sml file.
5. *postfix.sml* : This file contains the function *postfix(Command Sequence)*. It converts the command sequence into a postfix expression for evaluation by the VMC machine.
6. *vmc.sml* : This file contains the *rules* function under the _VMC_ structure which takes as an input the initial state of the program as V,M,C stacks and executes it to return the final state. 
7. *execute.sml* : Glues the postfix and the VMC together with the AST to output the final state of the programs as tupples of three lists.
8. *stack.sml* : Contains the STACK signature and Funstack Structure to be used in the VMC machine.