# To scan and Parse a file named **filename**
1. run *make*
2. run *use "while_ast.sml";*
3. run *parseFile "filename";*

### If you PC does not have make installed :
1. run *ml-lex lexer.lex*
2. run *ml-yacc parser.yacc*
3. run *sml*
4. run *use "while_ast.sml";*
5. run *parseFile "filename";*

## I have made certain decision to make the grammar unambiguous:
This includes using "(" and ")" at every expression which contains more than 1 Factor( A non Terminal dataType).
This makes the grammar unambigous. There are no reduce-reduce or shift-reduce conflicts in this grammar.

## I have used certain resources and taken help from certain pages on the web
1. http://rogerprice.org/ug/ug.pdf (A short documentation on the use of ML-LEX and ML-YACC)
2. http://cs.wellesley.edu/~cs235/fall08/lectures/35_YACC_revised.pdf 
   A lecture slide from Wellesley College on Languages and Automata