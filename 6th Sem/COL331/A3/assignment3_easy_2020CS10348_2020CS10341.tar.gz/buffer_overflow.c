# include "types.h"
# include "user.h"
# include "fcntl.h"

void foo () {
    printf (1 , "SECRET_STRING") ;
}
void vulnerable_function ( char * input ) {
    char buffer [8];
    strcpy ( buffer , input ) ;
    // printf (1 , "buffer content is : %s\n" , buffer ) ;
}
int main (int argc , char ** argv )
{
    int fd;
    fd = open ("payload", O_RDONLY ) ;
    char payload [100];
    // printf (1 , "address of function foo() is : %p\n" , foo ) ;
    read (fd , payload , 20) ;
    vulnerable_function ( payload );
    exit () ;
}