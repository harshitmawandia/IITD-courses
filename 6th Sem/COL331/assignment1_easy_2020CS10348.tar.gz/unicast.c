#include "types.h"
#include "user.h"
#include "date.h"

int main(int argc, char * argv[]){

    int type = argv[1][0] - '0';
    char* filename = argv[2];

    int arr[1000];
    int i = 0;

    fd = open(argv[1], O_RDONLY);
    if(fd < 0){
        printf(2, "Error opening file\n");
        exit();
    }

    for(i = 0; i < 1000; i++){
        if(read(fd, &arr[i], sizeof(int)) < 0){
            printf(2, "Error reading file\n");
            exit();
        }
    }

    for(i = 0; i < 1000; i++){
        printf(1, "%d\n", arr[i]);
    }




    exit();
}