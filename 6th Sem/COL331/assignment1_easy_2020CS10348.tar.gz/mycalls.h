#ifndef MYCALLS_H
#define MYCALLS_H
extern int trace_state;
extern int COUNT[28];
#endif