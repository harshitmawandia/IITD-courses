#include "types.h"
#include "stat.h"
#include "user.h"

int N_THREADS = 8;
double sum_sq = 0;

char *itoa2(int num) {
  static char buffer[8];
  int i = 6;

  do {
    buffer[i--] = (num % 10) + '0';
    num /= 10;
  } while (num > 0);

  for(;i>=0;i--){
	buffer[i] = '0';
  }

  buffer[7] = '\0';
//   printf(1,"buffer is %s\n", buffer);
  return (buffer);
}

char *itoa(int num) {
  static char buffer[8];
  int i = 0;

  do {
    buffer[i++] = (num % 10) + '0';
    num /= 10;
  } while (num > 0);

  buffer[i] = '\0';
  return (buffer);
}

char* dtoa(double num){
	int int_part = (int)num;
	// printf(1,"int_part is %d\n", int_part);
	int frac_part = (int)((num-int_part)*1000000);
	// printf(1,"frac_part is %d\n", frac_part);
	char* int_str = itoa(int_part);
	// printf(1,"int_str is %s\n", int_str);
	char* str = (char*)malloc(8);
	str[0] = int_str[0];
	char* frac_str = itoa(frac_part);
	// printf(1,"frac_str is %s\n", frac_str);
	str[1] = '.';
	str[2] = frac_str[5] ? frac_str[5] : '0';
	str[3] = frac_str[4] ? frac_str[4] : '0';
	str[4] = frac_str[3] ? frac_str[3] : '0';
	str[5] = frac_str[2] ? frac_str[2] : '0';
	str[6] = frac_str[1] ? frac_str[1] : '0';
	str[7] = '\0';
	// printf(1,"str is %s\n", str);

	return str;
}

double atof(char* str){
	int int_part = atoi(str);
	int frac_part = atoi(str+2);
	double num = int_part + frac_part*1.0/1000000;
	return num;
}

int worker(int start, int end, short *arr, int coordinator_pid){
	int sum = 0;
	for(int i=start; i<end; i++){
		sum+=arr[i];
	}
	char* sum_str = (char*)malloc(8);
	sum_str = itoa2(sum);
	if(send(getpid(), coordinator_pid, sum_str)!=0){
		printf(1,"Error sending sum to coordinator\n");
		exit();
		return -1;
	}else{
		printf(1,"Sent sum %d to coordinator\n", sum);
		exit();
		return 0;
	}
}

int unicast(short *arr, int size){
    int chunk = size/N_THREADS;

	int coordinator_pid = getpid();

	// int pids[N_THREADS];

	for(int i=0; i<N_THREADS;i++){
		if(getpid()!=coordinator_pid){
			break;
		}
		int start = i * chunk;
    	int end = (i + 1) * chunk;
		fork();
		if(getpid()!=coordinator_pid){
			worker(start, end, arr, coordinator_pid);
		}
	}

	int sum = 0;

	if(getpid()==coordinator_pid){
		for(int i=0; i<N_THREADS; i++){
			char* sum_str = (char*)malloc(8);
			if(recv(sum_str)!=0){
				printf(1,"Error receiving sum from worker\n");
				exit();
				return -1;
			}else{
				printf(1,"Received sum %s from worker\n ", sum_str);
				sum+=atoi(sum_str);
			}
		}
	}

    for(int i=0; i<N_THREADS; i++){
        wait();
    }

    return sum;
}

int multicastWorker(int start, int end, short *arr, int coordinator_pid){
	int sum = 0;
	for(int i=start; i<end; i++){
		sum+=arr[i];
	}
	char* sum_str = (char*)malloc(8);
	sum_str = itoa2(sum);
	if(send(getpid(), coordinator_pid, sum_str)!=0){
		printf(1,"Error sending sum to coordinator\n");
		exit();
		return -1;
	}
	printf(1,"Sent sum %d to coordinator\n", sum);
	
	char* str = (char*)malloc(8);
	
	// printf(1,"Waiting for mean from coordinator\n");

	if(recv(str)!=0){
		printf(1,"Error receiving mean from coordinator\n");
		exit();
		return -1;
	}
	sum_sq+=atof(str);

	// printf(1,"Received mean %s from coordinator\n", str);

	// double mean = atof(str);
	// double sum_sq = 0;
	// for(int i=start; i<end; i++){
	// 	sum_sq+=(arr[i]-mean)*(arr[i]-mean);
	// }

	// char* sum_sq_str = (char*)malloc(8);
	// sum_sq_str = dtoa(sum_sq);

	// if(send(getpid(), coordinator_pid, sum_sq_str)!=0){
	// 	printf(1,"Error sending sum_sq to coordinator\n");
	// 	exit();
	// 	return -1;
	// }

	// printf(1,"Sent sum_sq %s to coordinator\n", sum_sq_str);
	exit();
	return 0;	
}

double multicast(short *arr, int size){
    int chunk = size/N_THREADS;

	int coordinator_pid = getpid();

	int pids[N_THREADS];

	for(int i=0; i<N_THREADS;i++){
		if(getpid()!=coordinator_pid){
			break;
		}
		int start = i * chunk;
    	int end = (i + 1) * chunk;
		pids[i]=fork();
		if(getpid()!=coordinator_pid){
			multicastWorker(start, end, arr, coordinator_pid);
		}
	}

	int sum = 0;

	if(getpid()==coordinator_pid){
		for(int i=0; i<N_THREADS; i++){
			char* sum_str = (char*)malloc(8);
			if(recv(sum_str)!=0){
				printf(1,"Error receiving sum from worker\n");
				exit();
				return -1;
			}else{
				printf(1,"Received sum %s from worker\n ", sum_str);
				sum+=atoi(sum_str);
			}
		}
	}

    double mean = (sum+2010)*1.0/size ;
	char* str= dtoa(mean);

	printf(1,"Mean is %s\n", str);

	for(int i=0; i<N_THREADS; i++){
		printf(1,"Sending mean = %s to worker %d\n", str, pids[i]);
	}

    if(send_multi(getpid(),pids, str)!=0){
		printf(1,"Error sending mean to workers\n");
		exit();
		return -1;
	}

	// printf(1,"Sent mean to workers %d\n", a);

	// double sum_sq = 0;
	// for(int i=0; i<N_THREADS; i++){
	// 	char* sum_sq_str = (char*)malloc(8);
	// 	printf(1,"Waiting for sum_sq from worker %d\n", pids[i]);
	// 	if(recv(sum_sq_str)!=0){
	// 		printf(1,"Error receiving sum_sq from worker\n");
	// 		exit();
	// 		return -1;
	// 	}else{
	// 		printf(1,"Received sum_sq %s from worker\n ", sum_sq_str);
	// 		sum_sq+=atof(sum_sq_str);
	// 	}
	// }

	for(int i=0; i<N_THREADS; i++){
		wait();
	}

	double variance = sum_sq/size;
    return variance;
}

int
main(int argc, char *argv[])
{
	if(argc< 2){
		printf(1,"Need type and input filename\n");
		exit();
	}
	char *filename;
	filename=argv[2];
	int type = atoi(argv[1]);
	printf(1,"Type is %d and filename is %s\n",type, filename);

	int tot_sum = 0;	
	double variance = 0;

	int size=1000;
	short arr[size];
	char* c = (char*)malloc(1);
	int fd = open(filename, 0);
	for(int i=0; i<size; i++){
		read(fd, c, 1);
		arr[i]=2;
        // printf(1, "%d"  , arr[i]);
		read(fd, c, 1);
	}	
  	close(fd);
  	// this is to supress warning
  	printf(1,"first elem %d\n", arr[0]);

  	// ----FILL THE CODE HERE for unicast sum
    if(type==0){
	    tot_sum = unicast(arr, size);
    }else if(type==1){
		variance = multicast(arr, size);
	}

  	// ------------------

  	if(type==0){ //unicast sum
		printf(1,"Sum of array for file %s is %d\n", filename,tot_sum);
	}else if(type==1){ //multicast variance
		printf(1,"Variance of array for file %s is %d\n", filename,variance);
	}
	exit();
}
