#include "types.h"
#include "user.h"
#include "date.h"

#define N_THREADS 4

void multicastWorker(int coordinator_pid){
    char* msg = (char*)malloc(8);
    // printf(1,"Process %d is waiting for message\n", getpid());
    int a = recv(msg);
    int pid = getpid();
    if(a == 0){
        printf(1,"Process %d received: %s\n", pid, msg);
    }else{
        printf(1,"Error receiving message\n");
    }
    exit();
}


int main(int argc, char * argv[]){
    // printf(1,"pid: %d\n", getpid())
	int coordinator_pid = getpid();

	int pids[N_THREADS];

	for(int i=0; i<N_THREADS;i++){
		if(getpid()!=coordinator_pid){
			break;
		}
		pids[i]=fork();
		if(getpid()!=coordinator_pid){
			multicastWorker(coordinator_pid);
		}
	}

    if(getpid()==coordinator_pid){
        char* message = "Helloo";
        int b = send_multi(getpid(),pids, message);
        if(b == 0){
            printf(1,"Parent process sent: %s\n", message);
        }else{
            printf(1,"Error sending message\n");
        }
        for(int i=0; i<N_THREADS; i++){
            wait();
        }
    }

    exit();
    return 0; 
}