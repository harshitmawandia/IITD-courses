#include "types.h"
#include "user.h"
#include "date.h"
#include "fcntl.h"

int main(int argc, char * argv[]){
    ps();
    exit();
}