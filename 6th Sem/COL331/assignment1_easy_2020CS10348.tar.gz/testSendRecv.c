#include "types.h"
#include "user.h"
#include "date.h"


int main(int argc, char * argv[]){
    // printf(1,"pid: %d\n", getpid());
    int pid = fork();
    // printf(1,"Forked process with pid: %d\n", pid);
    if (pid == -1) {
        return 1;
    }


    if (pid == 0) {
        // Child process
        char message[8];
        // printf(1,"Child pid: %d  %d\n", getpid(), pid);
        int a = recv(message);
        if(a == 0){
            printf(1,"Child process received: %s\n", message);
        }else{
            printf(1,"Error receiving message\n");
        }
        exit();
    } else {
        // Parent process
        char message[8] = "Helloo";
        // printf(1,"Parent process sent: %s\n", message);
        // printf(1,"Senders pid: %d  %d\n", getpid(), pid);
        int b = send(getpid(), pid, message);
        if(b == 0){
            printf(1,"Parent process sent: %s\n", message);
        }else{
            printf(1,"Error sending message\n");
        }
        wait();
        exit();
    }
    return 0; 
}