//#pragma once

#include <bits/stdc++.h>

using namespace std;

int Inner(int a, int b);

int Outer(int a, int b);
