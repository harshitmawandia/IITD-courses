import Includes.*;
import java.util.*;
import javafx.util.Pair;

public class MerkleTree {

	// Check the TreeNode.java file for more details
	public TreeNode rootnode;

	public Pair<ArrayList<TreeNode>, ArrayList<TreeNode>> LowestCommonAncestor(TreeNode node1, TreeNode node2){
		ArrayList<TreeNode> path1, path2;
		path1 = new ArrayList<TreeNode>();
		path2 = new ArrayList<TreeNode>();
		TreeNode ptr1 = node1, ptr2 = node2;
		while(ptr1 != null){
			path1.add(ptr1);
			ptr1 = ptr1.parent;
		}
		while(ptr2 != null){
			path2.add(ptr2);
			ptr2 = ptr2.parent;
		}
		int m = path1.size();
		int n = path2.size();

		Collections.reverse(path1);
		Collections.reverse(path2);

		int lca_idx=Math.min(m,n)-1;
		for(int i=0; i<Math.min(m,n); i++){
			if(path1.get(i) != path2.get(i)){
				lca_idx = i-1;
				break;
			}
		}

		while(lca_idx > 0){
			path1.remove(0);
			path2.remove(0);
			lca_idx--;
		}
		
		Collections.reverse(path1);
		Collections.reverse(path2);
		
		return new Pair<ArrayList<TreeNode>, ArrayList<TreeNode>>(path1, path2);
	}
	
    /*==========================
    |- To be done by students -|
    ==========================*/
    /* Lab test to-do */

	public int GetLeafValue(TreeNode leaf) {
		/* Implement your code here */
		/* Remember to:
			- Turn on your camera
			- turn on your microphone
			- share your screen
			- begin recording the meeting
			- (just before submitting) rename your file as per the convention specified */
		
		return 0;
	}

	public void RangeUpdate(TreeNode lower, TreeNode upper, int increment_val){
		
		Pair<ArrayList<TreeNode>, ArrayList<TreeNode>> p = LowestCommonAncestor(lower, upper);
		ArrayList<TreeNode> path_lower = p.getKey();
		ArrayList<TreeNode> path_upper = p.getValue();

		return;
	}
}