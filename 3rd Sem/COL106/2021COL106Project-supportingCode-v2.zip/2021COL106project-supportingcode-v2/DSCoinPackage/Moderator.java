package DSCoinPackage;

public class Moderator
 {

  public void initializeDSCoin(DSCoin_Honest DSObj, int coinCount) {

  }
    
  public void initializeDSCoin(DSCoin_Malicious DSObj, int coinCount) {

  }
}
