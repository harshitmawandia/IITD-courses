package DSCoinPackage;

// import DSCoinPackage.TransactionQueue;
// import DSCoinPackage.BlockChain_Honest;
// import DSCoinPackage.Members;

public class DSCoin_Honest {

  public TransactionQueue pendingTransactions;
  public BlockChain_Honest bChain;
  public Members[] memberlist;
  public String latestCoinID;
}
