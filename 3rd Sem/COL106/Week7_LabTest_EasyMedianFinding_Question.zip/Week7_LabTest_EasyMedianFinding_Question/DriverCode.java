import Includes.*;
import java.util.*;
import java.io.*;

public class DriverCode{

	public static void main(String[] args)
    {
		// Add your own code here to verify `CalculateMedian`
		int[] L = {1, 2, 3};
		int median = Statistics.CalculateMedian(L);
		System.out.println(median);

		return;
    }
}
