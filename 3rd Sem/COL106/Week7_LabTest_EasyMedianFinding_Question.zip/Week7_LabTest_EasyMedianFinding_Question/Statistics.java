import Includes.*;
import java.util.*;

public class Statistics {
	
    /*==========================
    |- To be done by students -|
    ==========================*/
    /* Lab test to-do */

	public static int CalculateMedian(int[] L) {
		/* Implement your code here */
		/* Remember to:
			- Turn on your camera
			- turn on your microphone
			- share your screen
			- begin recording the meeting
			- (just before submitting) rename your file as per the convention specified */
		
		return -1;
	}
}