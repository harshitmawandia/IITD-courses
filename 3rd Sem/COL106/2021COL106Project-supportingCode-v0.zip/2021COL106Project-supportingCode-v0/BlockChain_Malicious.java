package Includes;

public class BlockChain_Malicious {

  public int tr_count;
  public static final String start_string = "DSCoin";
  public TransactionBlock[] lastBlocksList;

  public static boolean checkTransactionBlock (TransactionBlock tB) {

  }

  public TransactionBlock FindLongestValidChain () {

  }

  public void InsertBlock_Malicious (TransactionBlock newBlock) {

  }
}
