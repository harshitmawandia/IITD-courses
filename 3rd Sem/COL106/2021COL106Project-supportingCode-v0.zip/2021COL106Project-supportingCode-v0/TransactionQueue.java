package Includes;

public class TransactionQueue {

  public Transaction firstTransaction;
  public Transaction lastTransaction;
  public int numTransactions;

  public void AddTransactions (Transaction transaction) {

  }
  
  public Transaction RemoveTransaction () throws EmptyQueueException {

  }

  pulbic int size() {

  }
}
