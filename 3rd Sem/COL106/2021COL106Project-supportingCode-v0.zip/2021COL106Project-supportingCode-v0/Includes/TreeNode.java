package Includes;

public class TreeNode {

  public TreeNode parent;
  public TreeNode left;
  public TreeNode right;
  public String val;
}
