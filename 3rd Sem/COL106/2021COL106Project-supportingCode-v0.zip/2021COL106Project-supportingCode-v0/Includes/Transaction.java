package Includes;

public class Transaction {

  public String coinID;
  public Member Source;
  public Member Destination;
  public TransactionBlock coinsrc_block;
}
