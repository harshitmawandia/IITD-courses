package Includes;

public class Moderator
 {

  public DSCoin_Honest DSobj;
  // public DSCoin_Malicious DSobj;
  String[] issuedCoins; 

  public void initializeDSCoin(Members[] members, int tr_count) {

  }
}
